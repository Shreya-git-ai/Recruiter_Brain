import warnings
warnings.filterwarnings("ignore")
import os
os.environ["STREAMLIT_WATCHER_TYPE"] = "none"

import sys
# Dynamic path resolution to ensure 'app' package root is always found
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = current_dir
while root_dir and not os.path.exists(os.path.join(root_dir, "app")):
    parent = os.path.dirname(root_dir)
    if parent == root_dir:
        break
    root_dir = parent

if os.path.exists(os.path.join(root_dir, "app")):
    sys.path.insert(0, root_dir)
else:
    # Fallback to the default relative lookup path
    sys.path.append(os.path.abspath(os.path.join(current_dir, "..", "..")))

import pandas as pd
import streamlit as st

# 1. Imports from existing modules
from app.ui.styles import GLOBAL_CSS, SIDEBAR_CSS
from app.ui.components import (
    hero_section,
    feature_card,
    pipeline_step,
    tech_badge,
    candidate_card,
    explanation_panel,
    stat_card,
    section_header,
)

# Page configuration
st.set_page_config(page_title="Recruiter Brain — Home", layout="wide", page_icon="🧠")

# Inject static components and custom styles
st.markdown(GLOBAL_CSS, unsafe_allow_html=True)
st.markdown(SIDEBAR_CSS, unsafe_allow_html=True)

# 6. Same Sidebar Architecture
with st.sidebar:
    st.markdown("""
    <div class="sidebar-logo">
        <div class="sidebar-logo-icon">🧠</div>
        <div class="sidebar-logo-text">Recruiter Brain</div>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("""
    <div class="sidebar-status">
        <div class="sidebar-status-title">System Status</div>
        <div class="status-item"><div class="status-dot"></div>Engine: Ready</div>
        <div class="status-item"><div class="status-dot"></div>Data Sync: Live</div>
    </div>
    """, unsafe_allow_html=True)

# 2 & 3. Read ONLY from outputs/streamlit_output.csv using pd.read_csv
CSV_PATH = "outputs/streamlit_output.csv"
df = None

if os.path.exists(CSV_PATH):
    try:
        df_raw = pd.read_csv(CSV_PATH)
        if {"candidate_id", "rank", "score", "reasoning"}.issubset(df_raw.columns) and len(df_raw) > 0:
            df = df_raw.sort_values("rank").reset_index(drop=True)
    except Exception:
        df = None

# 17. If CSV is missing or invalid, show a professional "No Results Found" page
if df is None:
    st.markdown(hero_section(is_demo=True), unsafe_allow_html=True)
    st.markdown("<div style='padding: 40px 48px;'>", unsafe_allow_html=True)
    st.error("⚠️ Streamlit Output Source Missing or Damaged.")
    st.markdown("""
    <div style="
        background: white;
        border: 1px solid #e8ecf4;
        border-radius: 20px;
        padding: 60px;
        text-align: center;
        box-shadow: 0 2px 8px rgba(0,0,0,0.04);
        margin-top: 20px;
    ">
        <div style="font-size: 48px; margin-bottom: 16px;">🎯</div>
        <div style="font-size: 20px; font-weight: 600; color: #111827; margin-bottom: 8px;">No Evaluation Results Found</div>
        <div style="font-size: 14px; color: #9ca3af; max-width: 500px; margin: 0 auto;">
            The engine summary cannot be visualized because <code>outputs/streamlit_output.csv</code> is absent or empty. Please execute your processing pipelines asynchronously first.
        </div>
    </div>
    </div>
    """, unsafe_allow_html=True)
    st.stop()

# 7. Same Hero Section
is_demo_dataset = len(df) <= 200
st.markdown(hero_section(is_demo=is_demo_dataset), unsafe_allow_html=True)

# Initialize interactive state parameters cleanly
if "home_selected" not in st.session_state:
    st.session_state["home_selected"] = df.iloc[0].to_dict() if len(df) > 0 else None

# 9. Same Statistics Cards Layout
st.markdown(section_header("Platform Overview", "Key analytical points from evaluation results", "📊"), unsafe_allow_html=True)
st.markdown("<div style='padding: 0 48px;'>", unsafe_allow_html=True)
s1, s2, s3, s4 = st.columns(4)
with s1:
    st.markdown(stat_card(str(len(df)), "Total Pool Analyzed", "👥", "#6366f1"), unsafe_allow_html=True)
with s2:
    top_score = df["score"].max()
    st.markdown(stat_card(f"{top_score:.3f}", "Highest Matching Score", "🏆", "#10b981"), unsafe_allow_html=True)
with s3:
    avg_score = df["score"].mean()
    st.markdown(stat_card(f"{avg_score:.3f}", "Average Baseline Score", "📈", "#f59e0b"), unsafe_allow_html=True)
with s4:
    highly_qualified = len(df[df["score"] >= 0.7])
    st.markdown(stat_card(str(highly_qualified), "Highly Qualified (≥0.70)", "🎯", "#ef4444"), unsafe_allow_html=True)
st.markdown("</div>", unsafe_allow_html=True)

# 13 & 14 & 15. Directly show latest results preview instead of "Run Matching Engine"
st.markdown(section_header("Top Ranked Candidates Preview", "Direct insight into high-performing matches currently stored in data outputs", "⚡"), unsafe_allow_html=True)

st.markdown("<div style='padding: 0 48px;'>", unsafe_allow_html=True)
col_left, col_right = st.columns([2.2, 1])

with col_left:
    preview_df = df.head(5)
    for _, row in preview_df.iterrows():
        is_top3 = row["rank"] <= 3
        st.markdown(
            candidate_card(row["rank"], row["candidate_id"], row["score"], row["reasoning"], is_top3),
            unsafe_allow_html=True
        )
        if st.button("Inspect Alignment Details →", key=f"home_preview_{row['candidate_id']}"):
            st.session_state["home_selected"] = row.to_dict()

with col_right:
    # 15. Right side must use explanation_panel()
    st.markdown(explanation_panel(st.session_state.get("home_selected")), unsafe_allow_html=True)
st.markdown("</div>", unsafe_allow_html=True)

# 8. Same Feature Cards Architecture
st.markdown(section_header("Core Capabilities", "Advanced features running within our extraction framework", "🛠️"), unsafe_allow_html=True)
st.markdown("<div style='padding: 0 48px;'>", unsafe_allow_html=True)
f1, f2, f3 = st.columns(3)
with f1:
    st.markdown(feature_card("🧠", "Semantic Understanding", "Goes far beyond standard keyword detection to accurately prioritize deeper engineering experiences."), unsafe_allow_html=True)
with f2:
    st.markdown(feature_card("🎯", "Explainable Evaluation", "Transparent rating layers matching explicit evidence with candidate backgrounds perfectly."), unsafe_allow_html=True)
with f3:
    st.markdown(feature_card("⚡", "High-Performance Vectors", "Employs lightning-fast indexing structures ensuring rapid parsing for massive candidate pools."), unsafe_allow_html=True)
st.markdown("</div>", unsafe_allow_html=True)

# 11. Same "How It Works" Sequence
st.markdown(section_header("Processing Workflow", "Step-by-step intelligence breakdown", "🔄"), unsafe_allow_html=True)
st.markdown("<div style='padding: 0 48px;'>", unsafe_allow_html=True)
p1, p2, p3, p4 = st.columns(4)
with p1:
    st.markdown(pipeline_step("1", "📄", "Ingest Profile", "Loads diverse JSONL candidate logs securely.", "#6366f1"), unsafe_allow_html=True)
with p2:
    st.markdown(pipeline_step("2", "📐", "Vector Mapping", "Transforms text layers via semantic embeddings.", "#10b981"), unsafe_allow_html=True)
with p3:
    st.markdown(pipeline_step("3", "⚖️", "Rank Matrix", "Scores matching capabilities dynamically.", "#f59e0b"), unsafe_allow_html=True)
with p4:
    st.markdown(pipeline_step("4", "📝", "Generate Reasons", "Formulates precise structural text summaries.", "#ef4444"), unsafe_allow_html=True)
st.markdown("</div>", unsafe_allow_html=True)

# 12. Same Tech Stack Layout
st.markdown(section_header("Platform Infrastructure", "Core technology stack components powering processing layers", "⚙️"), unsafe_allow_html=True)
st.markdown("<div style='padding: 0 48px 40px 48px;'>", unsafe_allow_html=True)
st.markdown(f"""
<div style="background: white; border: 1px solid #e8ecf4; border-radius: 16px; padding: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
    {tech_badge("Python 3.10")}
    {tech_badge("Streamlit Enterprise")}
    {tech_badge("Pandas Engine")}
    {tech_badge("NumPy Arrays")}
    {tech_badge("Sentence Transformers")}
    {tech_badge("Scikit-Learn Matrix")}
</div>
""", unsafe_allow_html=True)
st.markdown("</div>", unsafe_allow_html=True)

# 10. Same About Section
st.markdown(section_header("About Recruiter Brain", "Designed for extreme performance and accuracy", "ℹ️"), unsafe_allow_html=True)
st.markdown("""
<div style="padding: 0 48px 60px 48px; font-size: 14px; color: #4b5563; line-height: 1.7; max-width: 900px;">
    Recruiter Brain bridges the gap between deep resume profiles and technical operational descriptions. 
    By assessing real candidate engineering merit, context values, and production experience patterns natively, 
    the engine skips shallow terminology limits entirely to optimize high-volume organizational filtering.
</div>
""", unsafe_allow_html=True)