import pandas as pd
import os

# Streamlit UI ka output — yahan pipeline likhti hai
STREAMLIT_OUTPUT_CSV = "outputs/streamlit_output.csv"

# Submission CSV — yeh kabhi touch nahi hoti UI se
SUBMISSION_CSV = "outputs/team_submission.csv"


def load_results():
    """Load from streamlit output CSV — single source of truth for UI."""
    if os.path.exists(STREAMLIT_OUTPUT_CSV):
        try:
            df = pd.read_csv(STREAMLIT_OUTPUT_CSV)
            if {"candidate_id", "rank", "score", "reasoning"}.issubset(df.columns) and len(df) > 0:
                return df.sort_values("rank").reset_index(drop=True)
        except Exception:
            pass
    return None


def detect_dataset_paths():
    if (
        os.path.exists("data/candidates.jsonl")
        and os.path.exists("data/candidate_embeddings.npy")
        and os.path.exists("data/candidate_ids.npy")
    ):
        return (
            "data/candidates.jsonl",
            "data/candidate_embeddings.npy",
            "data/candidate_ids.npy",
            2000,
            False,
        )
    else:
        return (
            "data/demo_candidates.jsonl",
            "data/demo_candidate_embeddings.npy",
            "data/demo_candidate_ids.npy",
            200,
            True,
        )


def format_score_color(score):
    if score >= 0.7:
        return "#10b981"
    elif score >= 0.5:
        return "#f59e0b"
    return "#ef4444"