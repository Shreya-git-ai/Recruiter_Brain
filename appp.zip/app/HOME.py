import warnings
warnings.filterwarnings("ignore")
import os
os.environ["STREAMLIT_WATCHER_TYPE"] = "none"

import sys
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

import streamlit as st
from src.pipeline import run_pipeline
from app.ui.styles import GLOBAL_CSS, SIDEBAR_CSS
from app.ui.components import (
    hero_section, feature_card, pipeline_step,
    tech_badge, candidate_card, explanation_panel, stat_card
)
from app.ui.utils import detect_dataset_paths

st.set_page_config(page_title="Recruiter Brain", layout="wide", page_icon="🧠")

st.markdown(GLOBAL_CSS, unsafe_allow_html=True)
st.markdown(SIDEBAR_CSS, unsafe_allow_html=True)

# Session state
if "results_df" not in st.session_state:
    st.session_state["results_df"] = None
if "selected" not in st.session_state:
    st.session_state["selected"] = None

# Dataset detection
candidates_path, embeddings_path, ids_path, MAX_SAMPLE, IS_DEMO = detect_dataset_paths()

# ===== SIDEBAR =====
with st.sidebar:
    st.markdown("""
    <div class="sidebar-logo">
        <div class="sidebar-logo-icon">🧠</div>
        <div class="sidebar-logo-text">Recruiter Brain</div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div class="sidebar-status">
        <div class="sidebar-status-title">System Status</div>
        <div class="status-item"><div class="status-dot"></div>Embeddings Ready</div>
        <div class="status-item"><div class="status-dot"></div>Pipeline Ready</div>
        <div class="status-item"><div class="status-dot"></div>CPU Optimised</div>
        <div class="status-item"><div class="status-dot"></div>Explainable AI Enabled</div>
    </div>
    """, unsafe_allow_html=True)

# ===== HERO =====
st.markdown(hero_section(IS_DEMO), unsafe_allow_html=True)

# ===== FEATURES =====
st.markdown("""
<div style="padding: 40px 48px 24px 48px;">
    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px;">
    </div>
</div>
""", unsafe_allow_html=True)

col1, col2, col3, col4 = st.columns(4)
with col1:
    st.markdown(feature_card("🔍", "Semantic Search", "Understand career meaning, not just keywords. Surface Tier-5 plain-language candidates."), unsafe_allow_html=True)
with col2:
    st.markdown(feature_card("📈", "Career Intelligence", "Evaluate growth, skills and career trajectories with ML scoring."), unsafe_allow_html=True)
with col3:
    st.markdown(feature_card("🧠", "Explainable AI", "Built-in reasoning with strong, specific explanations."), unsafe_allow_html=True)
with col4:
    st.markdown(feature_card("🎯", "Recruiter Focused", "Built for recruiting workflows with availability signals."), unsafe_allow_html=True)

# ===== STATS =====
st.markdown("<div style='padding: 0 48px;'>", unsafe_allow_html=True)
df_count = len(st.session_state["results_df"]) if st.session_state["results_df"] is not None else "—"

s1, s2, s3, s4 = st.columns(4)
with s1:
    st.markdown(stat_card("100,000+", "Candidates Processed", "👥"), unsafe_allow_html=True)
with s2:
    st.markdown(stat_card("85.3", "Avg Semantic Score", "⚡"), unsafe_allow_html=True)
with s3:
    st.markdown(stat_card("< 2 min", "Ranking Runtime", "⏱️"), unsafe_allow_html=True)
with s4:
    st.markdown(stat_card(str(df_count), "Last Run — Ranked", "🏆"), unsafe_allow_html=True)

st.markdown("</div>", unsafe_allow_html=True)

# ===== ABOUT SECTION =====
st.markdown("""
<div style="padding: 40px 48px;">
    <h2 style="font-size: 24px; font-weight: 700; color: #111827; margin-bottom: 8px;">About Recruiter Brain</h2>
    <p style="font-size: 15px; color: #6b7280; max-width: 700px; line-height: 1.7; margin-bottom: 0;">
        Recruiter Brain is an AI-powered talent intelligence platform that helps recruiters find
        and rank the best candidates. We go beyond keyword matching to understand skills,
        career paths, potential and real-world fit — under strict compute constraints
        (CPU-only, no external APIs, 5-minute ranking budget).
    </p>
</div>
""", unsafe_allow_html=True)

# ===== PIPELINE STEPS =====
st.markdown("""
<div style="padding:40px 48px;">
    <h2 style="
        font-size:22px;
        font-weight:700;
        color:#111827;
        margin-bottom:24px;
    ">
        How It Works
    </h2>
</div>
""", unsafe_allow_html=True)

steps = [
    ("🕵️", "Honeypot Detection", "Remove quality & fake profiles"),
    ("🔎", "Hard Filters", "Apply hard requirements"),
    ("🧬", "Semantic Matching", "Match based on meaning & context"),
    ("📊", "Career Fit", "Evaluate growth & trajectory"),
    ("📡", "Recruiter Signals", "Apply recruiter signals"),
    ("🏆", "Final Ranking", "Rank the best candidates"),
]

cols = st.columns(6)

for i, (col, (icon, title, desc)) in enumerate(zip(cols, steps), start=1):
    with col:
        st.markdown(
            pipeline_step(i, icon, title, desc),
            unsafe_allow_html=True
        )



# ===== TECH STACK =====
st.markdown("""
<div style="padding:40px 48px;">
    <h2 style="
        font-size:22px;
        font-weight:700;
        color:#111827;
        margin-bottom:20px;
    ">
        Built With Modern AI Technologies
    </h2>
</div>
""", unsafe_allow_html=True)

techs = [
    "🐍 Python",
    "🤗 Sentence Transformers",
    "📊 FAISS",
    "⚡ Scikit-Learn",
    "🐼 Pandas",
    "🎈 Streamlit"
]

cols = st.columns(len(techs))

for col, tech in zip(cols, techs):
    with col:
        st.markdown(
            tech_badge(tech),
            unsafe_allow_html=True
        )


# ===== RUN ENGINE =====
st.markdown("""
<div style="padding: 40px 48px;">
    <div style="
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 20px;
        padding: 36px;
        color: white;
    ">
        <h2 style="font-size: 22px; font-weight: 700; color: white; margin-bottom: 8px;">🚀 Run Matching Engine</h2>
        <p style="font-size: 14px; color: rgba(255,255,255,0.8); margin-bottom: 24px;">
            Configure your sample size and top-N, then run the full pipeline end-to-end
        </p>
    </div>
</div>
""", unsafe_allow_html=True)

with st.container():
    col_a, col_b, col_c = st.columns([2, 2, 1])
    with col_a:
        sample_size = st.slider("Candidate sample size", 10, MAX_SAMPLE, min(200, MAX_SAMPLE), step=10)
    with col_b:
        top_n = st.slider("Top N results (max 100)", 5, 100, 20, step=5)
    with col_c:
        st.markdown("<br>", unsafe_allow_html=True)
        run_clicked = st.button("🚀 Search Intelligent Candidates", use_container_width=True)

if run_clicked:
    with st.spinner("Running pipeline — filtering, scoring, ranking..."):
        try:
            from app.ui.utils import STREAMLIT_OUTPUT_CSV
            result_df = run_pipeline(
                candidates_path=candidates_path,
                output_path=STREAMLIT_OUTPUT_CSV,
                embeddings_path=embeddings_path,
                ids_path=ids_path,
                limit=sample_size,
                top_n=top_n,
            )
            st.session_state["results_df"] = result_df
            st.session_state["selected"] = None
            st.success(f"✅ Done — ranked top {len(result_df)} candidates from {sample_size} sample. Go to **Candidate Rankings** page.")
        except FileNotFoundError as e:
            st.error(f"Missing file: {e}")
        except Exception as e:
            st.error(f"Pipeline error: {e}")

# ===== RESULTS PREVIEW ON HOME =====
from app.ui.utils import load_results
df = load_results()
if df is not None:
    st.session_state["results_df"] = df
if df is not None:
    st.markdown("""
    <div style="padding: 40px 48px 0 48px;">
        <h2 style="font-size: 20px; font-weight: 700; color: #111827; margin-bottom: 4px;">Latest Results Preview</h2>
        <p style="font-size: 14px; color: #6b7280; margin-bottom: 20px;">Showing top 5 — go to Candidate Rankings for full list</p>
    </div>
    """, unsafe_allow_html=True)

    with st.container():
        col_main, col_right = st.columns([2.2, 1])

        with col_main:
            st.markdown("<div style='padding: 0 48px;'>", unsafe_allow_html=True)
            for _, row in df.head(5).iterrows():
                is_top3 = row["rank"] <= 3
                st.markdown(
                    candidate_card(row["rank"], row["candidate_id"], row["score"], row["reasoning"], is_top3),
                    unsafe_allow_html=True
                )
                if st.button("View Details →", key=f"home_btn_{row['candidate_id']}"):
                    st.session_state["selected"] = row.to_dict()
            st.markdown("</div>", unsafe_allow_html=True)

        with col_right:
            st.markdown("<div style='padding-right: 48px;'>", unsafe_allow_html=True)
            st.markdown(explanation_panel(st.session_state.get("selected")), unsafe_allow_html=True)
            st.markdown("</div>", unsafe_allow_html=True)

# ===== FOOTER =====

st.markdown("""
<style>
[data-testid="stAppViewContainer"] {
    padding-bottom: 120px;
}
</style>

<div style="
    padding:32px 48px;
    border-top:1px solid #e8ecf4;
    margin-top:80px;
    display:flex;
    flex-wrap:wrap;
    justify-content:space-between;
    align-items:center;
    gap:10px;
    width:100%;
    box-sizing:border-box;
">
    <div style="font-size:13px;color:#9ca3af;">
        🧠 <strong style="color:#374151;">Recruiter Brain</strong> — Smarter Hiring. Better Talent. Stronger Teams.
    </div>

    
</div>
""", unsafe_allow_html=True)
